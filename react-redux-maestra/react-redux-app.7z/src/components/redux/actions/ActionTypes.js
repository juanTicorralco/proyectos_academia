const ActionTypes = {
  INCREMENTAR: "INCREMENTAR",
  DISMINUIR: "DISMINUIR",
};

export default ActionTypes;
