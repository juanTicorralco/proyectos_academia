import ClassComponent2 from "./components/ClassComponent2";
import { Provider } from "react-redux";
import { createStore } from "redux";
import contadorReducer from "./redux/reducers/ContadorReducer";
const store = createStore(contadorReducer);

const App = () => {
  <Provider store={store}>
    <ClassComponent2 />
  </Provider>;
};
export default App;
