const Home = () => {
  return (
    <div>
      <h1>Hola! Bienvenido</h1>
      <p> En esta pagina vas a encontrar los mejores paises para visitar</p>
    </div>
  );
};

export default Home;
