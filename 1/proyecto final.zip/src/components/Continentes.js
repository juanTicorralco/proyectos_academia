const Continentes = () => {
  return (
    <div>
      <h1>Parte de Continentes</h1>
      <p> En esta parte deberian estar los continentes :v!</p>
    </div>
  );
};

export default Continentes;
