const PageNotFound = () => {
  return (
    <div>
      <h1>UUUUUPPPSSS!</h1>
      <p> Algo salio mal....</p>
    </div>
  );
};

export default PageNotFound;
